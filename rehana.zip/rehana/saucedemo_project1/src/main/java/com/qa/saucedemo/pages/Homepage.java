package com.qa.saucedemo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.saucedemo.base.BaseClass;



public class Homepage extends BaseClass {

	

	    // Locators for Home Page
	@FindBy(className= "bm-burger-button")
	
public  WebElement Button; 
	@FindBy(id="logout_sidebar_link")
	public WebElement logOut;

	  // Locator for cart icon

	    // Constructor
	    public Homepage() {
	        // Initialize WebElements with the current driver
	        PageFactory.initElements(driver, this);
	    }

	    // Method to add an item to the cart
	    public void Menu() {
	       Button.click();
	    }

	    // Method to go to the cart
	    public void LogoutLink() {
	        logOut.click();
	    }
	}
