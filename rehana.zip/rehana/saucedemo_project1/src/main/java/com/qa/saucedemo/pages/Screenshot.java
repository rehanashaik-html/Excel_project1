package com.qa.saucedemo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Screenshot {
    private WebDriver driver;

    // Constructor to initialize WebDriver
    public Screenshot(WebDriver driver) {
        this.driver = driver;
    }

    // Method to take a screenshot
    public void takeScreenshot(String filePath) {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File location = new File(filePath);
        
        try {
            Files.copy(screenshot.toPath(), location.toPath());
            System.out.println("Screenshot saved at: " + location.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

