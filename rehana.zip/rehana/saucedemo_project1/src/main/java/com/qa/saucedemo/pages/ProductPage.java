package com.qa.saucedemo.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ProductPage {

    WebDriver driver;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(className = "product_sort_container")
    private WebElement sortDropdown;

    public void applyFilter(String value) {
        Select dropdown = new Select(sortDropdown);
        dropdown.selectByValue(value); // Select the option with the given value
    }
    @FindBy(className="inventory_item_name")
   public WebElement productname;
    public void name() {
    	productname.click();
    }
    
    
    @FindBy(className="inventory_details_back_button")
    public WebElement back1;
     public void back1() {
     
     	back1.click();
     	 
}}