package com.qa.saucedemo.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.saucedemo.base.BaseClass;

public class AddToCartPage extends BaseClass {

    // Locators for Home Page
	@FindBy(xpath = "//button[@class='btn_primary btn_inventory']")
	
public  WebElement addToCartButton; // Locator for add to cart button
	@FindBy(xpath = "//*[@class='shopping_cart_link fa-layers fa-fw']")
	public WebElement cartIcon;

	  // Locator for cart icon

	    // Constructor
	    public AddToCartPage() {
	        // Initialize WebElements with the current driver
	        PageFactory.initElements(driver, this);
	    }

	    // Method to add an item to the cart
	    public void addItemToCart() {
	        addToCartButton.click();
	    }

	    // Method to go to the cart
	    public void goToCart() {
	        cartIcon.click();
	    
	    
	        
	    
	    
	    
	    
	    
	    
	    }
	}
