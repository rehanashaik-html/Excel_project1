package com.qa.saucedemo.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.saucedemo.base.BaseClass;

public class removefromCart extends BaseClass{

	
	
	@FindBy(xpath ="//button[contains(@class, 'btn_secondary') and contains(@class, 'cart_button')]")
	public WebElement removebutton;

	@FindBy(className ="btn_secondary")
	public WebElement continueshopping;

	public removefromCart() {
		PageFactory.initElements(driver, this);
	
	}
	public  void removelink() {
		removebutton.click();
		}
	public  void continueshoppinglink() {
		continueshopping.click();
		}
	
	
	
}