package com.qa.saucedemo.testcases;



import java.io.IOException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.qa.saucedemo.base.BaseClass;
import com.qa.saucedemo.pages.AddToCartPage;
import com.qa.saucedemo.pages.Homepage;
import com.qa.saucedemo.pages.Loginpage;
import com.qa.saucedemo.pages.ProductPage;
import com.qa.saucedemo.pages.Screenshot;
import com.qa.saucedemo.pages.removefromCart;

public class LoginTestCase extends BaseClass {

    Loginpage lp;
    Homepage hp;
    ProductPage pr;
    AddToCartPage ap;
    removefromCart re;
    Screenshot Sc;
    

    public LoginTestCase() throws IOException {
      super();
    }

    @BeforeSuite
    public void setup() {
        initialization();
        lp = new Loginpage();
        hp = new Homepage();
        pr = new ProductPage(driver); // Ensure this line is correct
        ap = new AddToCartPage();
        re = new removefromCart();
        Sc= new Screenshot(driver);
    }
    

    @Test(priority = 1)
    public void loginpageTitleTest() {
        String title = lp.validateLoginPageTitle();
        Assert.assertEquals("Swag Labs", title);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\LoginPageTitleTest.jpg");
    }

    @Test(priority = 2)
    public void loginTest() throws InterruptedException {
        lp.login(props.getProperty("username"), props.getProperty("password"));
        Thread.sleep(2000);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\LoginTest.jpg");
    }
    
    @Test(priority=3)
    public  void testfilter() throws InterruptedException {
    	pr.applyFilter("lohi");
    	Thread.sleep(2000);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\TestFilter.jpg");
    }
    @Test(priority=4)
    public void testproductname() throws InterruptedException {
    	pr.name();
    	Thread.sleep(2000);
    	Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\TestProductName.jpg");
    }
    @Test(priority = 6)
    public void testAddItemToCart() throws InterruptedException {
    	
        // Add an item to the cart
        ap.addItemToCart();
        Thread.sleep(2000);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\addtocart.jpg");
    }
    
    @Test(priority=5)
    public void testback() throws InterruptedException {
    	
    	pr.back1();
    	Thread.sleep(2000);
    
    }
    
    @Test(priority=7)
    public void testgotocart() throws InterruptedException {
    	
    	ap.goToCart();
    	Thread.sleep(2000);
    	 Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\gotocart.jpg");

      
    }
    @Test(priority=8)
    public void testremovebutton() throws InterruptedException {
    	
    	re.removelink();
    	Thread.sleep(2000);
    	Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\Remove.jpg");
    }
    @Test(priority=9)
    public void testcontinue() throws InterruptedException {
    re.continueshoppinglink();
    Thread.sleep(2000);
    Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\continue.jpg");
    }
        @Test(priority = 10)
    public void testButton() throws InterruptedException {
    	
        // Add an item to the cart
        hp.Menu();
        Thread.sleep(2000);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\Menu.jpg");    
       }
  

    @Test(priority = 11)
    public void testlogoutLink() throws InterruptedException {
 
         hp.LogoutLink();
        Thread.sleep(2000);
        Sc.takeScreenshot("C:\\Users\\REHANA\\eclipse-workspace\\newworkspace\\saucedemo_project1\\src\\test\\resources\\Screenshot1\\Logout.jpg"); 
        }
    @AfterSuite
    public void tearDown() {
        driver.quit();
    }
}

    	
    	
    	
    	
    
    	   
  












